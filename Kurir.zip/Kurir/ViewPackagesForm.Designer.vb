﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewPackagesForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvViewPackagesForm = New System.Windows.Forms.DataGridView()
        Me.BackgroundWorker1 = New System.ComponentModel.BackgroundWorker()
        Me.btnBackVPF = New System.Windows.Forms.Button()
        Me.btnSelectPackages = New System.Windows.Forms.Button()
        Me.lblCourierID3 = New System.Windows.Forms.Label()
        Me.txtCourierID3 = New System.Windows.Forms.TextBox()
        Me.btnUpdatePackageStatus = New System.Windows.Forms.Button()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.lblStatusPackages = New System.Windows.Forms.Label()
        Me.lblPackageID2 = New System.Windows.Forms.Label()
        Me.txtPackageID2 = New System.Windows.Forms.TextBox()
        CType(Me.dgvViewPackagesForm, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvViewPackagesForm
        '
        Me.dgvViewPackagesForm.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvViewPackagesForm.Location = New System.Drawing.Point(12, 12)
        Me.dgvViewPackagesForm.Name = "dgvViewPackagesForm"
        Me.dgvViewPackagesForm.RowHeadersWidth = 62
        Me.dgvViewPackagesForm.RowTemplate.Height = 28
        Me.dgvViewPackagesForm.Size = New System.Drawing.Size(772, 342)
        Me.dgvViewPackagesForm.TabIndex = 0
        '
        'btnBackVPF
        '
        Me.btnBackVPF.Location = New System.Drawing.Point(12, 404)
        Me.btnBackVPF.Name = "btnBackVPF"
        Me.btnBackVPF.Size = New System.Drawing.Size(73, 34)
        Me.btnBackVPF.TabIndex = 1
        Me.btnBackVPF.Text = "Back"
        Me.btnBackVPF.UseVisualStyleBackColor = True
        '
        'btnSelectPackages
        '
        Me.btnSelectPackages.Location = New System.Drawing.Point(118, 384)
        Me.btnSelectPackages.Name = "btnSelectPackages"
        Me.btnSelectPackages.Size = New System.Drawing.Size(157, 37)
        Me.btnSelectPackages.TabIndex = 2
        Me.btnSelectPackages.Text = "Select Packages"
        Me.btnSelectPackages.UseVisualStyleBackColor = True
        '
        'lblCourierID3
        '
        Me.lblCourierID3.AutoSize = True
        Me.lblCourierID3.Location = New System.Drawing.Point(444, 377)
        Me.lblCourierID3.Name = "lblCourierID3"
        Me.lblCourierID3.Size = New System.Drawing.Size(81, 20)
        Me.lblCourierID3.TabIndex = 3
        Me.lblCourierID3.Text = "Courier ID"
        '
        'txtCourierID3
        '
        Me.txtCourierID3.Location = New System.Drawing.Point(448, 408)
        Me.txtCourierID3.Name = "txtCourierID3"
        Me.txtCourierID3.Size = New System.Drawing.Size(95, 26)
        Me.txtCourierID3.TabIndex = 4
        Me.txtCourierID3.Text = "CourierID"
        '
        'btnUpdatePackageStatus
        '
        Me.btnUpdatePackageStatus.Location = New System.Drawing.Point(281, 377)
        Me.btnUpdatePackageStatus.Name = "btnUpdatePackageStatus"
        Me.btnUpdatePackageStatus.Size = New System.Drawing.Size(157, 48)
        Me.btnUpdatePackageStatus.TabIndex = 5
        Me.btnUpdatePackageStatus.Text = "Update Packages Status"
        Me.btnUpdatePackageStatus.UseVisualStyleBackColor = True
        '
        'cmbStatus
        '
        Me.cmbStatus.FormattingEnabled = True
        Me.cmbStatus.Location = New System.Drawing.Point(669, 406)
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.Size = New System.Drawing.Size(103, 28)
        Me.cmbStatus.TabIndex = 6
        '
        'lblStatusPackages
        '
        Me.lblStatusPackages.AutoSize = True
        Me.lblStatusPackages.Location = New System.Drawing.Point(665, 377)
        Me.lblStatusPackages.Name = "lblStatusPackages"
        Me.lblStatusPackages.Size = New System.Drawing.Size(56, 20)
        Me.lblStatusPackages.TabIndex = 7
        Me.lblStatusPackages.Text = "Status"
        '
        'lblPackageID2
        '
        Me.lblPackageID2.AutoSize = True
        Me.lblPackageID2.Location = New System.Drawing.Point(558, 377)
        Me.lblPackageID2.Name = "lblPackageID2"
        Me.lblPackageID2.Size = New System.Drawing.Size(92, 20)
        Me.lblPackageID2.TabIndex = 8
        Me.lblPackageID2.Text = "Package ID"
        '
        'txtPackageID2
        '
        Me.txtPackageID2.Location = New System.Drawing.Point(562, 408)
        Me.txtPackageID2.Name = "txtPackageID2"
        Me.txtPackageID2.Size = New System.Drawing.Size(95, 26)
        Me.txtPackageID2.TabIndex = 9
        Me.txtPackageID2.Text = "PackageID"
        '
        'ViewPackagesForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtPackageID2)
        Me.Controls.Add(Me.lblPackageID2)
        Me.Controls.Add(Me.lblStatusPackages)
        Me.Controls.Add(Me.cmbStatus)
        Me.Controls.Add(Me.btnUpdatePackageStatus)
        Me.Controls.Add(Me.txtCourierID3)
        Me.Controls.Add(Me.lblCourierID3)
        Me.Controls.Add(Me.btnSelectPackages)
        Me.Controls.Add(Me.btnBackVPF)
        Me.Controls.Add(Me.dgvViewPackagesForm)
        Me.Name = "ViewPackagesForm"
        Me.Text = "ViewPackagesForm"
        CType(Me.dgvViewPackagesForm, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvViewPackagesForm As DataGridView
    Friend WithEvents BackgroundWorker1 As System.ComponentModel.BackgroundWorker
    Friend WithEvents btnBackVPF As Button
    Friend WithEvents btnSelectPackages As Button
    Friend WithEvents lblCourierID3 As Label
    Friend WithEvents txtCourierID3 As TextBox
    Friend WithEvents btnUpdatePackageStatus As Button
    Friend WithEvents cmbStatus As ComboBox
    Friend WithEvents lblStatusPackages As Label
    Friend WithEvents lblPackageID2 As Label
    Friend WithEvents txtPackageID2 As TextBox
End Class
