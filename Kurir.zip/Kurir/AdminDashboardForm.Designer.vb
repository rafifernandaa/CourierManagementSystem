﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class AdminDashboardForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.lblTotalPackages = New System.Windows.Forms.Label()
        Me.lblActiveCouriers = New System.Windows.Forms.Label()
        Me.lblPendingDeliveries = New System.Windows.Forms.Label()
        Me.btnPackages = New System.Windows.Forms.Button()
        Me.btnCouriers = New System.Windows.Forms.Button()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoginToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NavigateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PackagesToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CouriersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnHistory = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblTotalPackages
        '
        Me.lblTotalPackages.AutoSize = True
        Me.lblTotalPackages.Location = New System.Drawing.Point(106, 94)
        Me.lblTotalPackages.Name = "lblTotalPackages"
        Me.lblTotalPackages.Size = New System.Drawing.Size(118, 20)
        Me.lblTotalPackages.TabIndex = 0
        Me.lblTotalPackages.Text = "Total Packages"
        '
        'lblActiveCouriers
        '
        Me.lblActiveCouriers.AutoSize = True
        Me.lblActiveCouriers.Location = New System.Drawing.Point(309, 94)
        Me.lblActiveCouriers.Name = "lblActiveCouriers"
        Me.lblActiveCouriers.Size = New System.Drawing.Size(115, 20)
        Me.lblActiveCouriers.TabIndex = 1
        Me.lblActiveCouriers.Text = "Active Couriers"
        '
        'lblPendingDeliveries
        '
        Me.lblPendingDeliveries.AutoSize = True
        Me.lblPendingDeliveries.Location = New System.Drawing.Point(517, 94)
        Me.lblPendingDeliveries.Name = "lblPendingDeliveries"
        Me.lblPendingDeliveries.Size = New System.Drawing.Size(139, 20)
        Me.lblPendingDeliveries.TabIndex = 2
        Me.lblPendingDeliveries.Text = "Pending Deliveries"
        '
        'btnPackages
        '
        Me.btnPackages.Location = New System.Drawing.Point(46, 271)
        Me.btnPackages.Name = "btnPackages"
        Me.btnPackages.Size = New System.Drawing.Size(204, 62)
        Me.btnPackages.TabIndex = 3
        Me.btnPackages.Text = "Manage Packages"
        Me.btnPackages.UseVisualStyleBackColor = True
        '
        'btnCouriers
        '
        Me.btnCouriers.Location = New System.Drawing.Point(544, 271)
        Me.btnCouriers.Name = "btnCouriers"
        Me.btnCouriers.Size = New System.Drawing.Size(204, 62)
        Me.btnCouriers.TabIndex = 4
        Me.btnCouriers.Text = "Manage Couriers"
        Me.btnCouriers.UseVisualStyleBackColor = True
        '
        'MenuStrip1
        '
        Me.MenuStrip1.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem, Me.NavigateToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(800, 33)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoginToolStripMenuItem, Me.ExitToolStripMenuItem1})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(77, 29)
        Me.ExitToolStripMenuItem.Text = "Home"
        '
        'LoginToolStripMenuItem
        '
        Me.LoginToolStripMenuItem.Name = "LoginToolStripMenuItem"
        Me.LoginToolStripMenuItem.Size = New System.Drawing.Size(158, 34)
        Me.LoginToolStripMenuItem.Text = "Login"
        '
        'ExitToolStripMenuItem1
        '
        Me.ExitToolStripMenuItem1.Name = "ExitToolStripMenuItem1"
        Me.ExitToolStripMenuItem1.Size = New System.Drawing.Size(158, 34)
        Me.ExitToolStripMenuItem1.Text = "Exit"
        '
        'NavigateToolStripMenuItem
        '
        Me.NavigateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PackagesToolStripMenuItem, Me.CouriersToolStripMenuItem})
        Me.NavigateToolStripMenuItem.Name = "NavigateToolStripMenuItem"
        Me.NavigateToolStripMenuItem.Size = New System.Drawing.Size(98, 29)
        Me.NavigateToolStripMenuItem.Text = "Navigate"
        '
        'PackagesToolStripMenuItem
        '
        Me.PackagesToolStripMenuItem.Name = "PackagesToolStripMenuItem"
        Me.PackagesToolStripMenuItem.Size = New System.Drawing.Size(186, 34)
        Me.PackagesToolStripMenuItem.Text = "Packages"
        '
        'CouriersToolStripMenuItem
        '
        Me.CouriersToolStripMenuItem.Name = "CouriersToolStripMenuItem"
        Me.CouriersToolStripMenuItem.Size = New System.Drawing.Size(186, 34)
        Me.CouriersToolStripMenuItem.Text = "Couriers"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(65, 29)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(164, 34)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'btnHistory
        '
        Me.btnHistory.Location = New System.Drawing.Point(293, 271)
        Me.btnHistory.Name = "btnHistory"
        Me.btnHistory.Size = New System.Drawing.Size(204, 62)
        Me.btnHistory.TabIndex = 6
        Me.btnHistory.Text = "History"
        Me.btnHistory.UseVisualStyleBackColor = True
        '
        'AdminDashboardForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnHistory)
        Me.Controls.Add(Me.btnCouriers)
        Me.Controls.Add(Me.btnPackages)
        Me.Controls.Add(Me.lblPendingDeliveries)
        Me.Controls.Add(Me.lblActiveCouriers)
        Me.Controls.Add(Me.lblTotalPackages)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "AdminDashboardForm"
        Me.Text = "DashboardForm"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTotalPackages As Label
    Friend WithEvents lblActiveCouriers As Label
    Friend WithEvents lblPendingDeliveries As Label
    Friend WithEvents btnPackages As Button
    Friend WithEvents btnCouriers As Button
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents NavigateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PackagesToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents CouriersToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoginToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents btnHistory As Button
End Class
