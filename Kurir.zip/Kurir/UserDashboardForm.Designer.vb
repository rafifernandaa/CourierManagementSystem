﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class UserDashboardForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.LoginToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.NavigateToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PackagesToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.CouriersToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblTotalPackages = New System.Windows.Forms.Label()
        Me.lblActiveCouriers = New System.Windows.Forms.Label()
        Me.lblPendingDeliveries = New System.Windows.Forms.Label()
        Me.btnViewPackages = New System.Windows.Forms.Button()
        Me.btnViewCouriers = New System.Windows.Forms.Button()
        Me.MenuStrip2.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.GripMargin = New System.Windows.Forms.Padding(2, 2, 0, 2)
        Me.MenuStrip2.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem, Me.NavigateToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Size = New System.Drawing.Size(800, 33)
        Me.MenuStrip2.TabIndex = 6
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.LoginToolStripMenuItem1, Me.ExitToolStripMenuItem2})
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(77, 29)
        Me.ExitToolStripMenuItem.Text = "Home"
        '
        'LoginToolStripMenuItem1
        '
        Me.LoginToolStripMenuItem1.Name = "LoginToolStripMenuItem1"
        Me.LoginToolStripMenuItem1.Size = New System.Drawing.Size(270, 34)
        Me.LoginToolStripMenuItem1.Text = "Login"
        '
        'ExitToolStripMenuItem2
        '
        Me.ExitToolStripMenuItem2.Name = "ExitToolStripMenuItem2"
        Me.ExitToolStripMenuItem2.Size = New System.Drawing.Size(270, 34)
        Me.ExitToolStripMenuItem2.Text = "Exit"
        '
        'NavigateToolStripMenuItem
        '
        Me.NavigateToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PackagesToolStripMenuItem1, Me.CouriersToolStripMenuItem1})
        Me.NavigateToolStripMenuItem.Name = "NavigateToolStripMenuItem"
        Me.NavigateToolStripMenuItem.Size = New System.Drawing.Size(98, 29)
        Me.NavigateToolStripMenuItem.Text = "Navigate"
        '
        'PackagesToolStripMenuItem1
        '
        Me.PackagesToolStripMenuItem1.Name = "PackagesToolStripMenuItem1"
        Me.PackagesToolStripMenuItem1.Size = New System.Drawing.Size(270, 34)
        Me.PackagesToolStripMenuItem1.Text = "Packages"
        '
        'CouriersToolStripMenuItem1
        '
        Me.CouriersToolStripMenuItem1.Name = "CouriersToolStripMenuItem1"
        Me.CouriersToolStripMenuItem1.Size = New System.Drawing.Size(270, 34)
        Me.CouriersToolStripMenuItem1.Text = "Couriers"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem1})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(65, 29)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem1
        '
        Me.AboutToolStripMenuItem1.Name = "AboutToolStripMenuItem1"
        Me.AboutToolStripMenuItem1.Size = New System.Drawing.Size(270, 34)
        Me.AboutToolStripMenuItem1.Text = "About"
        '
        'lblTotalPackages
        '
        Me.lblTotalPackages.AutoSize = True
        Me.lblTotalPackages.Location = New System.Drawing.Point(114, 89)
        Me.lblTotalPackages.Name = "lblTotalPackages"
        Me.lblTotalPackages.Size = New System.Drawing.Size(118, 20)
        Me.lblTotalPackages.TabIndex = 7
        Me.lblTotalPackages.Text = "Total Packages"
        '
        'lblActiveCouriers
        '
        Me.lblActiveCouriers.AutoSize = True
        Me.lblActiveCouriers.Location = New System.Drawing.Point(304, 89)
        Me.lblActiveCouriers.Name = "lblActiveCouriers"
        Me.lblActiveCouriers.Size = New System.Drawing.Size(115, 20)
        Me.lblActiveCouriers.TabIndex = 8
        Me.lblActiveCouriers.Text = "Active Couriers"
        '
        'lblPendingDeliveries
        '
        Me.lblPendingDeliveries.AutoSize = True
        Me.lblPendingDeliveries.Location = New System.Drawing.Point(521, 89)
        Me.lblPendingDeliveries.Name = "lblPendingDeliveries"
        Me.lblPendingDeliveries.Size = New System.Drawing.Size(139, 20)
        Me.lblPendingDeliveries.TabIndex = 9
        Me.lblPendingDeliveries.Text = "Pending Deliveries"
        '
        'btnViewPackages
        '
        Me.btnViewPackages.Location = New System.Drawing.Point(103, 233)
        Me.btnViewPackages.Name = "btnViewPackages"
        Me.btnViewPackages.Size = New System.Drawing.Size(204, 62)
        Me.btnViewPackages.TabIndex = 10
        Me.btnViewPackages.Text = "View Packages"
        Me.btnViewPackages.UseVisualStyleBackColor = True
        '
        'btnViewCouriers
        '
        Me.btnViewCouriers.Location = New System.Drawing.Point(456, 233)
        Me.btnViewCouriers.Name = "btnViewCouriers"
        Me.btnViewCouriers.Size = New System.Drawing.Size(204, 62)
        Me.btnViewCouriers.TabIndex = 11
        Me.btnViewCouriers.Text = "View Couriers"
        Me.btnViewCouriers.UseVisualStyleBackColor = True
        '
        'UserDashboardForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnViewCouriers)
        Me.Controls.Add(Me.btnViewPackages)
        Me.Controls.Add(Me.lblPendingDeliveries)
        Me.Controls.Add(Me.lblActiveCouriers)
        Me.Controls.Add(Me.lblTotalPackages)
        Me.Controls.Add(Me.MenuStrip2)
        Me.Name = "UserDashboardForm"
        Me.Text = "UserDashboardForm"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip2 As MenuStrip
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents LoginToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem2 As ToolStripMenuItem
    Friend WithEvents NavigateToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents PackagesToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents CouriersToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem1 As ToolStripMenuItem
    Friend WithEvents lblTotalPackages As Label
    Friend WithEvents lblActiveCouriers As Label
    Friend WithEvents lblPendingDeliveries As Label
    Friend WithEvents btnViewPackages As Button
    Friend WithEvents btnViewCouriers As Button
End Class
