﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PackagesForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvPackages = New System.Windows.Forms.DataGridView()
        Me.btnAddPackage = New System.Windows.Forms.Button()
        Me.btnUpdatePackage = New System.Windows.Forms.Button()
        Me.btnDeletePackage = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblPackageName = New System.Windows.Forms.Label()
        Me.txtPackageName = New System.Windows.Forms.TextBox()
        Me.lblStatus = New System.Windows.Forms.Label()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.lblDestinationAddress = New System.Windows.Forms.Label()
        Me.txtDestinationAddress = New System.Windows.Forms.TextBox()
        Me.lblCourierID = New System.Windows.Forms.Label()
        Me.txtCourierID = New System.Windows.Forms.TextBox()
        Me.lblPackageID = New System.Windows.Forms.Label()
        Me.txtPackageID = New System.Windows.Forms.TextBox()
        CType(Me.dgvPackages, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvPackages
        '
        Me.dgvPackages.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPackages.Location = New System.Drawing.Point(227, 23)
        Me.dgvPackages.Name = "dgvPackages"
        Me.dgvPackages.RowHeadersWidth = 62
        Me.dgvPackages.RowTemplate.Height = 28
        Me.dgvPackages.Size = New System.Drawing.Size(543, 295)
        Me.dgvPackages.TabIndex = 0
        '
        'btnAddPackage
        '
        Me.btnAddPackage.Location = New System.Drawing.Point(36, 43)
        Me.btnAddPackage.Name = "btnAddPackage"
        Me.btnAddPackage.Size = New System.Drawing.Size(150, 36)
        Me.btnAddPackage.TabIndex = 1
        Me.btnAddPackage.Text = "Add Packages"
        Me.btnAddPackage.UseVisualStyleBackColor = True
        '
        'btnUpdatePackage
        '
        Me.btnUpdatePackage.Location = New System.Drawing.Point(36, 129)
        Me.btnUpdatePackage.Name = "btnUpdatePackage"
        Me.btnUpdatePackage.Size = New System.Drawing.Size(150, 36)
        Me.btnUpdatePackage.TabIndex = 2
        Me.btnUpdatePackage.Text = "Update Packages"
        Me.btnUpdatePackage.UseVisualStyleBackColor = True
        '
        'btnDeletePackage
        '
        Me.btnDeletePackage.Location = New System.Drawing.Point(36, 216)
        Me.btnDeletePackage.Name = "btnDeletePackage"
        Me.btnDeletePackage.Size = New System.Drawing.Size(150, 36)
        Me.btnDeletePackage.TabIndex = 3
        Me.btnDeletePackage.Text = "Delete Packages"
        Me.btnDeletePackage.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.Location = New System.Drawing.Point(12, 399)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(57, 39)
        Me.btnBack.TabIndex = 4
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'lblPackageName
        '
        Me.lblPackageName.AutoSize = True
        Me.lblPackageName.Location = New System.Drawing.Point(223, 336)
        Me.lblPackageName.Name = "lblPackageName"
        Me.lblPackageName.Size = New System.Drawing.Size(113, 20)
        Me.lblPackageName.TabIndex = 5
        Me.lblPackageName.Text = "PackageName"
        '
        'txtPackageName
        '
        Me.txtPackageName.Location = New System.Drawing.Point(227, 373)
        Me.txtPackageName.Name = "txtPackageName"
        Me.txtPackageName.Size = New System.Drawing.Size(100, 26)
        Me.txtPackageName.TabIndex = 6
        Me.txtPackageName.Text = "PackageName"
        '
        'lblStatus
        '
        Me.lblStatus.AutoSize = True
        Me.lblStatus.Location = New System.Drawing.Point(365, 336)
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(56, 20)
        Me.lblStatus.TabIndex = 7
        Me.lblStatus.Text = "Status"
        '
        'cmbStatus
        '
        Me.cmbStatus.FormattingEnabled = True
        Me.cmbStatus.Items.AddRange(New Object() {"Pending", "In Transit", "Delivered"})
        Me.cmbStatus.Location = New System.Drawing.Point(369, 373)
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.Size = New System.Drawing.Size(129, 28)
        Me.cmbStatus.TabIndex = 8
        Me.cmbStatus.Text = "Status"
        '
        'lblDestinationAddress
        '
        Me.lblDestinationAddress.AutoSize = True
        Me.lblDestinationAddress.Location = New System.Drawing.Point(512, 336)
        Me.lblDestinationAddress.Name = "lblDestinationAddress"
        Me.lblDestinationAddress.Size = New System.Drawing.Size(149, 20)
        Me.lblDestinationAddress.TabIndex = 9
        Me.lblDestinationAddress.Text = "DestinationAddress"
        '
        'txtDestinationAddress
        '
        Me.txtDestinationAddress.Location = New System.Drawing.Point(516, 375)
        Me.txtDestinationAddress.Name = "txtDestinationAddress"
        Me.txtDestinationAddress.Size = New System.Drawing.Size(100, 26)
        Me.txtDestinationAddress.TabIndex = 10
        Me.txtDestinationAddress.Text = "DestinationAddress"
        '
        'lblCourierID
        '
        Me.lblCourierID.AutoSize = True
        Me.lblCourierID.Location = New System.Drawing.Point(678, 336)
        Me.lblCourierID.Name = "lblCourierID"
        Me.lblCourierID.Size = New System.Drawing.Size(77, 20)
        Me.lblCourierID.TabIndex = 11
        Me.lblCourierID.Text = "CourierID"
        '
        'txtCourierID
        '
        Me.txtCourierID.Location = New System.Drawing.Point(682, 375)
        Me.txtCourierID.Name = "txtCourierID"
        Me.txtCourierID.Size = New System.Drawing.Size(100, 26)
        Me.txtCourierID.TabIndex = 12
        Me.txtCourierID.Text = "CourierID"
        '
        'lblPackageID
        '
        Me.lblPackageID.AutoSize = True
        Me.lblPackageID.Location = New System.Drawing.Point(95, 336)
        Me.lblPackageID.Name = "lblPackageID"
        Me.lblPackageID.Size = New System.Drawing.Size(88, 20)
        Me.lblPackageID.TabIndex = 13
        Me.lblPackageID.Text = "PackageID"
        '
        'txtPackageID
        '
        Me.txtPackageID.Location = New System.Drawing.Point(99, 373)
        Me.txtPackageID.Name = "txtPackageID"
        Me.txtPackageID.Size = New System.Drawing.Size(100, 26)
        Me.txtPackageID.TabIndex = 14
        Me.txtPackageID.Text = "PackageID"
        '
        'PackagesForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.txtPackageID)
        Me.Controls.Add(Me.lblPackageID)
        Me.Controls.Add(Me.txtCourierID)
        Me.Controls.Add(Me.lblCourierID)
        Me.Controls.Add(Me.txtDestinationAddress)
        Me.Controls.Add(Me.lblDestinationAddress)
        Me.Controls.Add(Me.cmbStatus)
        Me.Controls.Add(Me.lblStatus)
        Me.Controls.Add(Me.txtPackageName)
        Me.Controls.Add(Me.lblPackageName)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnDeletePackage)
        Me.Controls.Add(Me.btnUpdatePackage)
        Me.Controls.Add(Me.btnAddPackage)
        Me.Controls.Add(Me.dgvPackages)
        Me.Name = "PackagesForm"
        Me.Text = "PackagesForm"
        CType(Me.dgvPackages, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvPackages As DataGridView
    Friend WithEvents btnAddPackage As Button
    Friend WithEvents btnUpdatePackage As Button
    Friend WithEvents btnDeletePackage As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents lblPackageName As Label
    Friend WithEvents txtPackageName As TextBox
    Friend WithEvents lblStatus As Label
    Friend WithEvents cmbStatus As ComboBox
    Friend WithEvents lblDestinationAddress As Label
    Friend WithEvents txtDestinationAddress As TextBox
    Friend WithEvents lblCourierID As Label
    Friend WithEvents txtCourierID As TextBox
    Friend WithEvents lblPackageID As Label
    Friend WithEvents txtPackageID As TextBox
End Class
