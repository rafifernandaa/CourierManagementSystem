﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ViewCourierForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvViewCouriers = New System.Windows.Forms.DataGridView()
        Me.btnUpdateStatus = New System.Windows.Forms.Button()
        Me.txtCourierID2 = New System.Windows.Forms.TextBox()
        Me.lblCourierID2 = New System.Windows.Forms.Label()
        Me.chkAvailability2 = New System.Windows.Forms.CheckBox()
        Me.lblAvailability2 = New System.Windows.Forms.Label()
        Me.btnBackVCF = New System.Windows.Forms.Button()
        CType(Me.dgvViewCouriers, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvViewCouriers
        '
        Me.dgvViewCouriers.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvViewCouriers.Location = New System.Drawing.Point(12, 12)
        Me.dgvViewCouriers.Name = "dgvViewCouriers"
        Me.dgvViewCouriers.RowHeadersWidth = 62
        Me.dgvViewCouriers.RowTemplate.Height = 28
        Me.dgvViewCouriers.Size = New System.Drawing.Size(776, 311)
        Me.dgvViewCouriers.TabIndex = 0
        '
        'btnUpdateStatus
        '
        Me.btnUpdateStatus.Location = New System.Drawing.Point(163, 363)
        Me.btnUpdateStatus.Name = "btnUpdateStatus"
        Me.btnUpdateStatus.Size = New System.Drawing.Size(174, 47)
        Me.btnUpdateStatus.TabIndex = 1
        Me.btnUpdateStatus.Text = "Update Status"
        Me.btnUpdateStatus.UseVisualStyleBackColor = True
        '
        'txtCourierID2
        '
        Me.txtCourierID2.Location = New System.Drawing.Point(400, 384)
        Me.txtCourierID2.Name = "txtCourierID2"
        Me.txtCourierID2.Size = New System.Drawing.Size(76, 26)
        Me.txtCourierID2.TabIndex = 2
        Me.txtCourierID2.Text = "Courier ID"
        '
        'lblCourierID2
        '
        Me.lblCourierID2.AutoSize = True
        Me.lblCourierID2.Location = New System.Drawing.Point(396, 348)
        Me.lblCourierID2.Name = "lblCourierID2"
        Me.lblCourierID2.Size = New System.Drawing.Size(81, 20)
        Me.lblCourierID2.TabIndex = 3
        Me.lblCourierID2.Text = "Courier ID"
        '
        'chkAvailability2
        '
        Me.chkAvailability2.AutoSize = True
        Me.chkAvailability2.Location = New System.Drawing.Point(535, 386)
        Me.chkAvailability2.Name = "chkAvailability2"
        Me.chkAvailability2.Size = New System.Drawing.Size(98, 24)
        Me.chkAvailability2.TabIndex = 4
        Me.chkAvailability2.Text = "Available"
        Me.chkAvailability2.UseVisualStyleBackColor = True
        '
        'lblAvailability2
        '
        Me.lblAvailability2.AutoSize = True
        Me.lblAvailability2.Location = New System.Drawing.Point(531, 348)
        Me.lblAvailability2.Name = "lblAvailability2"
        Me.lblAvailability2.Size = New System.Drawing.Size(56, 20)
        Me.lblAvailability2.TabIndex = 5
        Me.lblAvailability2.Text = "Status"
        '
        'btnBackVCF
        '
        Me.btnBackVCF.Location = New System.Drawing.Point(12, 407)
        Me.btnBackVCF.Name = "btnBackVCF"
        Me.btnBackVCF.Size = New System.Drawing.Size(71, 31)
        Me.btnBackVCF.TabIndex = 6
        Me.btnBackVCF.Text = "Back"
        Me.btnBackVCF.UseVisualStyleBackColor = True
        '
        'ViewCourierForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnBackVCF)
        Me.Controls.Add(Me.lblAvailability2)
        Me.Controls.Add(Me.chkAvailability2)
        Me.Controls.Add(Me.lblCourierID2)
        Me.Controls.Add(Me.txtCourierID2)
        Me.Controls.Add(Me.btnUpdateStatus)
        Me.Controls.Add(Me.dgvViewCouriers)
        Me.Name = "ViewCourierForm"
        Me.Text = "ViewCourierForm"
        CType(Me.dgvViewCouriers, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvViewCouriers As DataGridView
    Friend WithEvents btnUpdateStatus As Button
    Friend WithEvents txtCourierID2 As TextBox
    Friend WithEvents lblCourierID2 As Label
    Friend WithEvents chkAvailability2 As CheckBox
    Friend WithEvents lblAvailability2 As Label
    Friend WithEvents btnBackVCF As Button
End Class
